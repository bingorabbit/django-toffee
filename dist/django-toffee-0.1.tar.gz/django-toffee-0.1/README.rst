=====
Django Toffee
=====

Quick start
-----------

1. Add "toffee" to your INSTALLED_APPS setting like this::

    INSTALLED_APPS = (
        ...
        'toffee',
    )

